snail-mail
==========

Bringing personalisation to your emails through a web application that allows you to personalise emails they send to others. Emails can be sent from any gmail/google app account. 
