exports.show = function(req, res){
    res.render('write_email');
};