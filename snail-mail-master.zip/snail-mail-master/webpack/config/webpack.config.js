let config = require('./common.js');
config.devtool = 'eval';
module.exports = config;
